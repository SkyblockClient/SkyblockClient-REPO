DO NOT post this texture pack in another social media website or anywhere else and claim it is your's.
I swear to god if you do I will find you and rip every part of your body until I'm satisfied.

In another note, enjoy the pack :)